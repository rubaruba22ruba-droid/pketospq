# .tron mrkt: мини-апп
1. Создайте репозиторий на GitHub, загрузите сюда все файлы из архива (Add file → Upload files).
2. Settings → Pages → Source: Deploy from branch → main / root → Save.
3. Ссылка вида `https://ЛОГИН.github.io/РЕПО/` пойдёт в `WEBAPP_URL` в `.env` бэкенда. Адрес сервера в мини-апп вписывать не нужно: бот передаёт его сам.
